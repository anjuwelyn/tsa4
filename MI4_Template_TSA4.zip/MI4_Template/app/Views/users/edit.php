<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>
</head>
<body>

    <h1>Edit User</h1>

    <?php if (session('validation')): ?>
        <ul style="color: red;">
            <?php foreach (session('validation')->getErrors() as $error): ?>
                <li><?= esc($error) ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <form action="<?= site_url('users/update/' . $user['id']) ?>"
          method="post" enctype="multipart/form-data">

        <?= csrf_field() ?>

        <label>Username:</label><br>
        <input type="text" name="username"
               value="<?= old('username', $user['username']) ?>"><br><br>

        <label>Full Name:</label><br>
        <input type="text" name="full_name"
               value="<?= old('full_name', $user['full_name']) ?>"><br><br>

        <label>New Avatar:</label><br>
        <input type="file" name="avatar" accept="image/png,image/jpeg"><br><br>

        <?php if (!empty($user['avatar'])): ?>
            <p>Current Avatar:</p>
            <img src="<?= base_url('writable/uploads/avatars/' . $user['avatar']) ?>"
                 width="80" height="80">
            <br><br>
        <?php endif; ?>

        <button type="submit">Update User</button>
    </form>

    <br>
    <a href="<?= site_url('users') ?>">Back to Users</a>

</body>
</html>