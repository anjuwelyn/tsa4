<!DOCTYPE html>
<html>
<head>
    <title>New User</title>
</head>
<body>

    <h1>New User</h1>

    <?php if (session('validation')): ?>
        <ul style="color: red;">
            <?php foreach (session('validation')->getErrors() as $error): ?>
                <li><?= esc($error) ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <form action="<?= site_url('users/store') ?>" method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>

        <label>Username:</label><br>
        <input type="text" name="username" value="<?= old('username') ?>"><br><br>

        <label>Full Name:</label><br>
        <input type="text" name="full_name" value="<?= old('full_name') ?>"><br><br>

        <label>Avatar:</label><br>
        <input type="file" name="avatar" accept="image/png,image/jpeg"><br><br>

        <button type="submit">Save User</button>
    </form>

    <br>
    <a href="<?= site_url('users') ?>">Back to Users</a>

</body>
</html>