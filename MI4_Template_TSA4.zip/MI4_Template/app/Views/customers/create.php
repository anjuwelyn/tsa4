<!DOCTYPE html>
<html>
<head>
    <title>Add Customer</title>
</head>
<body>

    <h1>Add Customer</h1>

    <?php if (session('validation')): ?>
        <ul style="color: red;">
            <?php foreach (session('validation')->getErrors() as $error): ?>
                <li><?= esc($error) ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <form action="<?= site_url('customers/store') ?>" method="post">
        <?= csrf_field() ?>

        <label>Full Name:</label><br>
        <input type="text" name="full_name" value="<?= old('full_name') ?>"><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" value="<?= old('email') ?>"><br><br>

        <label>Phone:</label><br>
        <input type="text" name="phone" value="<?= old('phone') ?>"><br><br>

        <button type="submit">Save Customer</button>
    </form>

    <br>
    <a href="<?= site_url('customers') ?>">Back to Customers</a>

</body>
</html>