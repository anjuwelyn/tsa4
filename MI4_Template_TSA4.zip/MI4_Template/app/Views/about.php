<h1>About</h1>
<p>This is a basic Point-of-Sale System made using CodeIgniter 4.</p>

<a href="/MI4_Template">Home</a> |
<a href="/MI4_Template/about">About</a> |
<a href="/MI4_Template/customers">Customer Accounts</a> |
<a href="/MI4_Template/users">User Accounts</a>