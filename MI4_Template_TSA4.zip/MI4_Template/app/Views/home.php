<h1>POS System</h1>
<p>Welcome to our Point-of-Sale System.</p>

<a href="/MI4_Template">Home</a> |
<a href="/MI4_Template/about">About</a> |
<a href="/MI4_Template/customers">Customer Accounts</a> |
<a href="/MI4_Template/users">User Accounts</a>
<a href="<?= site_url('customers/create') ?>">Add Customer</a>