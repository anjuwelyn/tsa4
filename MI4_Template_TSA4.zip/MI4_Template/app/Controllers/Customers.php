<?php

namespace App\Controllers;

use App\Models\CustomerModel;

class Customers extends BaseController
{
    public function index()
    {
        $customerModel = new CustomerModel();

        $data['customers'] = $customerModel->findAll();

        return view('customers', $data);
    }

    public function create()
{
    return view('customers/create');
}
public function store()
{
    $rules = [
        'full_name' => 'required|max_length[100]',
        'email'    => 'required|valid_email|max_length[100]',
        'phone'    => 'permit_empty|numeric|max_length[20]',
    ];

    if (! $this->validate($rules)) {
        return redirect()->back()
            ->withInput()
            ->with('validation', $this->validator);
    }

    $model = new CustomerModel();

    $model->insert([
        'full_name' => $this->request->getPost('full_name'),
        'email'     => $this->request->getPost('email'),
        'phone'     => $this->request->getPost('phone'),
    ]);

    return redirect()->to(site_url('customers'))
        ->with('success', 'Customer added successfully.');
}
public function edit($id)
{
    $model = new CustomerModel();
    $customer = $model->find($id);

    if (!$customer) {
        throw new \CodeIgniter\Exceptions\PageNotFoundException('Customer not found');
    }

    return view('customers/edit', [
        'customer' => $customer
    ]);
}

public function update($id)
{
    $rules = [
        'full_name' => 'required|max_length[100]',
        'email'     => 'required|valid_email|max_length[100]',
        'phone'     => 'permit_empty|numeric|max_length[20]',
    ];

    if (! $this->validate($rules)) {
        return redirect()->back()
            ->withInput()
            ->with('validation', $this->validator);
    }

    $model = new CustomerModel();

    $model->update($id, [
        'full_name' => $this->request->getPost('full_name'),
        'email'     => $this->request->getPost('email'),
        'phone'     => $this->request->getPost('phone'),
    ]);

    return redirect()->to(site_url('customers'))
        ->with('success', 'Customer updated successfully.');
}
}