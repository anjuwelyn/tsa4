<?php

namespace App\Controllers;

use App\Models\UserModel;

class Users extends BaseController
{
    public function index()
    {
        $userModel = new UserModel();

        $data['users'] = $userModel->findAll();

        return view('users', $data);
    }


    public function create()
{
    return view('users/new');
}

public function store()
{
    $rules = [
        'username' => 'required|is_unique[users.username]|max_length[50]',
        'full_name' => 'required|max_length[100]',
        'avatar' => 'permit_empty|is_image[avatar]|mime_in[avatar,image/jpg,image/jpeg,image/png]|max_size[avatar,2048]',
    ];

    if (! $this->validate($rules)) {
        return redirect()->back()
            ->withInput()
            ->with('validation', $this->validator);
    }

    $avatarName = null;
    $file = $this->request->getFile('avatar');

    if ($file && $file->isValid() && ! $file->hasMoved()) {
        $avatarName = $file->getRandomName();
        $file->move(WRITEPATH . 'uploads/avatars', $avatarName);
    }

    $model = new UserModel();

    $model->insert([
        'username' => $this->request->getPost('username'),
        'full_name' => $this->request->getPost('full_name'),
        'avatar' => $avatarName,
        'created_at' => date('Y-m-d H:i:s'),
    ]);

    return redirect()->to(site_url('users'))
        ->with('success', 'User added successfully.');
}

public function edit($id)
{
    $model = new UserModel();
    $user = $model->find($id);

    if (!$user) {
        throw new \CodeIgniter\Exceptions\PageNotFoundException('User not found');
    }

    return view('users/edit', [
        'user' => $user
    ]);
}

public function update($id)
{
    $model = new UserModel();
    $user = $model->find($id);

    if (!$user) {
        throw new \CodeIgniter\Exceptions\PageNotFoundException('User not found');
    }

    $rules = [
        'username' => "required|is_unique[users.username,id,{$id}]|max_length[50]",
        'full_name' => 'required|max_length[100]',
        'avatar' => 'permit_empty|is_image[avatar]|mime_in[avatar,image/jpg,image/jpeg,image/png]|max_size[avatar,2048]',
    ];

    if (! $this->validate($rules)) {
        return redirect()->back()
            ->withInput()
            ->with('validation', $this->validator);
    }

    $data = [
        'username' => $this->request->getPost('username'),
        'full_name' => $this->request->getPost('full_name'),
    ];

    $file = $this->request->getFile('avatar');

    if ($file && $file->isValid() && ! $file->hasMoved()) {
        $avatarName = $file->getRandomName();
        $file->move(WRITEPATH . 'uploads/avatars', $avatarName);
        $data['avatar'] = $avatarName;
    }

    $model->update($id, $data);

    return redirect()->to(site_url('users'))
        ->with('success', 'User updated successfully.');
}
}