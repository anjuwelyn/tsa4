-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 07, 2026 at 01:29 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pos_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `first_name`, `last_name`, `full_name`, `email`, `phone`, `address`, `created_at`) VALUES
(1, NULL, NULL, 'Ana Santos', 'ana@email.com', '09171234567', NULL, '2026-09-22 16:42:10'),
(2, NULL, NULL, 'Mark Cruz', 'mark@email.com', '09181234567', NULL, '2026-09-22 16:42:10'),
(3, NULL, NULL, 'Liza Reyes', 'liza@email.com', '09191234567', NULL, '2026-09-22 16:42:10'),
(4, NULL, NULL, 'John Garcia', 'john@email.com', '09201234567', NULL, '2026-09-22 16:42:10'),
(5, NULL, NULL, 'Mia Dela Cruz', 'mia@email.com', '09211234567', NULL, '2026-09-22 16:42:10'),
(6, NULL, NULL, 'anjelene casimiro', 'anjelenecasimiro9@gmail.com', '9458024845', NULL, '2026-10-02 10:21:59');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `full_name`, `avatar`, `created_at`) VALUES
(1, 'admin', '$2y$10$u3cRcUALEy82pnw5AikmSeOeFo7b2iMrPBeRXVYazJf1uuftFPrzC', 'Angela Santos', NULL, '2026-09-22 16:42:21'),
(2, 'cashier01', '$2y$10$6mdOLJaYh09sIMa9bfTB/OmgXHqLsn1JUFL8qyBvATRgNjEZ/RIgG', 'Mark Cruz', NULL, '2026-09-22 16:42:21'),
(3, 'staff01', '$2y$10$KMs2T.YnETXLNgcLOAqK0.zGX5QlRKNTdY6Zo29apDN5l86WVtUDa', 'Liza Reyes', NULL, '2026-09-22 16:42:21'),
(4, 'staff02', '$2y$10$KMs2T.YnETXLNgcLOAqK0.zGX5QlRKNTdY6Zo29apDN5l86WVtUDa', 'John Garcia', NULL, '2026-09-22 16:42:21'),
(5, 'manager01', '$2y$10$xsXGR/SmyOAq85FocPtg2OYkXq6g8X2bTvhG8g.0e5tISeZf4Pl7W', 'Mia Dela Cruz', NULL, '2026-09-22 16:42:21'),
(6, 'anjuwelyn', '$2y$10$.7h62BAsfK9mvICTgvjQRuAfiQVQ20u/PmPM.pMyNtlZyAPW.wPOO', 'Anjelene Casimiro', '1790908190_e01d09c9eabca216a8ec.png', '2026-10-02 02:29:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
